import secrets

# Generate a random 32-byte hexadecimal key
SECRET_KEY = '4817aec6002d5fdb9d3a50e2f4d5ca05b78a81ff9e7e2452733c99445262b741'
ALGORITHM = "HS256"